<!doctype html>
<html class="no-js" ang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title> <?php echo e(config('app.name', 'Laravel')); ?> </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Place favicon.ico in the root directory -->
        <link rel="stylesheet" href="<?php echo e(asset('css/vendor.css')); ?>">
        <!-- Theme initialization -->
        <link rel="stylesheet" id="theme-style" href="<?php echo e(asset('css/app-blue.css')); ?>">
    </head>
    <body>
        
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Reference block for JS -->
        <script src="<?php echo e(asset('js/vendor.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>