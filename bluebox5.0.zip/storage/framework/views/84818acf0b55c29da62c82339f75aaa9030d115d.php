<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
  <meta name="description" content="">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('css/vendor.css')); ?>">
  <!-- Theme initialization -->
  <link rel="stylesheet" id="theme-style" href="<?php echo e(asset('css/app-blue.css')); ?>">
</head>
<body>

  <div class="main-wrapper">

      <div class="app" id="app">          
          <!-- header -->
          <?php echo $__env->make('bluebox.layouts.components.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <!-- header-END -->
          
          <!-- sidebar -->
          <?php echo $__env->make('bluebox.layouts.components.sider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <!-- sidebar-END -->

          <article class="content dashboard-page">
              <!-- Content -->
                <?php echo $__env->yieldContent('content'); ?>
              <!-- Content-END -->
          </article> 
          
          <!-- sidebar -->
          <?php echo $__env->make('bluebox.layouts.components.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <!-- sidebar-END -->
      </div>

  </div>
  
  <!-- Scripts -->
    <script src="<?php echo e(asset('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
