<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <!-- Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('css/vendor.css')); ?>">
  <!-- Theme initialization -->
  <link rel="stylesheet" id="theme-style" href="css/app-blue.css">
</head>
<body>

  <div class="main-wrapper">
      <div class="app" id="app">
          <header class="header">
              <div class="header-block header-block-collapse d-lg-none d-xl-none">
                  <button class="collapse-btn" id="sidebar-collapse-btn">
                      <i class="fa fa-bars"></i>
                  </button>
              </div>
              <div class="header-block header-block-search">
                  <form role="search">
                      <div class="input-container">
                          <i class="fa fa-search"></i>
                          <input type="search" placeholder="Search">
                          <div class="underline"></div>
                      </div>
                  </form>
              </div>

              <div class="header-block header-block-nav">
                  <ul class="nav-profile">
                      <li class="notifications new">
                          <a href="" data-toggle="dropdown">
                              <i class="fa fa-bell-o"></i>
                              <sup>
                                  <span class="counter">8</span>
                              </sup>
                          </a>
                          <div class="dropdown-menu notifications-dropdown-menu">
                              <ul class="notifications-container">
                                  <li>
                                      <a href="" class="notification-item">
                                          <div class="img-col">
                                              <div class="img" style="background-image: url('assets/faces/3.jpg')"></div>
                                          </div>
                                          <div class="body-col">
                                              <p>
                                                  <span class="accent">Zack Alien</span> pushed new commit:
                                                  <span class="accent">Fix page load performance issue</span>. </p>
                                          </div>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="" class="notification-item">
                                          <div class="img-col">
                                              <div class="img" style="background-image: url('assets/faces/5.jpg')"></div>
                                          </div>
                                          <div class="body-col">
                                              <p>
                                                  <span class="accent">Amaya Hatsumi</span> started new task:
                                                  <span class="accent">Dashboard UI design.</span>. </p>
                                          </div>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="" class="notification-item">
                                          <div class="img-col">
                                              <div class="img" style="background-image: url('assets/faces/8.jpg')"></div>
                                          </div>
                                          <div class="body-col">
                                              <p>
                                                  <span class="accent">Andy Nouman</span> deployed new version of
                                                  <span class="accent">NodeJS REST Api V3</span>
                                              </p>
                                          </div>
                                      </a>
                                  </li>
                              </ul>
                              <footer>
                                  <ul>
                                      <li>
                                          <a href=""> View All </a>
                                      </li>
                                  </ul>
                              </footer>
                          </div>
                      </li>
                      <li class="profile dropdown">
                          <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                              <div class="img" style="background-image: url('https://avatars3.githubusercontent.com/u/3959008?v=3&s=40')"> </div>
                              <span class="name"> <?php echo e(Auth::user()->name); ?> </span>
                          </a>
                          <div class="dropdown-menu profile-dropdown-menu" aria-labelledby="dropdownMenu1">
                              <a class="dropdown-item" href="#">
                                  <i class="fa fa-user icon"></i> Profile </a>
                              <a class="dropdown-item" href="#">
                                  <i class="fa fa-bell icon"></i> Notifications </a>
                              <a class="dropdown-item" href="#">
                                  <i class="fa fa-gear icon"></i> Settings </a>
                              <div class="dropdown-divider"></div>
                              <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                                  onclick="event.preventDefault();
                                           document.getElementById('logout-form').submit();">
                                  <i class="fa fa-power-off icon"></i> Logout
                              </a>

                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                  <?php echo e(csrf_field()); ?>

                              </form>
                          </div>
                      </li>
                  </ul>
              </div>
          </header>
          <aside class="sidebar">
              <div class="sidebar-container">
                  <div class="sidebar-header">
                      <div class="brand">
                        <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('img/bluebox/bluebox-logo-white.svg')); ?>" alt="logo-svg" width="100%"></a>    
                      </div>
                  </div>
                  <nav class="menu">
                      <ul class="sidebar-menu metismenu" id="sidebar-menu">
                          <li class="active">
                              <a href="index.html">
                                  <i class="fa fa-home"></i> Dashboard </a>
                          </li>
                          <li>
                              <a href="">
                                  <i class="fa fa-th-large"></i> Items Manager
                                  <i class="fa arrow"></i>
                              </a>
                              <ul class="sidebar-nav">
                                  <li>
                                      <a href="items-list.html"> Items List </a>
                                  </li>
                                  <li>
                                      <a href="item-editor.html"> Item Editor </a>
                                  </li>
                              </ul>
                          </li>
                          <li>
                              <a href="screenful.html">
                                  <i class="fa fa-bar-chart"></i> Agile Metrics
                                  <span class="label label-screenful">by Screenful</span>
                              </a>
                          </li>
                      </ul>
                  </nav>
              </div>
          </aside>
          <div class="sidebar-overlay" id="sidebar-overlay"></div>
          <div class="sidebar-mobile-menu-handle" id="sidebar-mobile-menu-handle"></div>
          <div class="mobile-menu-handle"></div>
          <article class="content dashboard-page">

                <?php echo $__env->yieldContent('content'); ?>

          </article>
          <footer class="footer">
              <div class="footer-block buttons">
                  © 2012 - 2018 LARAVEL<a href="#"></a>
              </div>
              <div class="footer-block author">
                  <ul>
                      <li> LOREM
                          <a href="#">LOREM</a>
                      </li>
                      <li>
                          <a href="#">bluebox</a>
                      </li>
                  </ul>
              </div>
          </footer>
      </div>
  </div>

  <!-- Reference block for JS -->
  <div class="ref" id="ref">
      <div class="color-primary"></div>
      <div class="chart">
          <div class="color-primary"></div>
          <div class="color-secondary"></div>
      </div>
  </div>
  
  <!-- Scripts -->
    <script src="<?php echo e(asset('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
