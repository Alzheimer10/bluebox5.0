<footer class="footer">
    <div class="footer-block buttons">
        © 2012 - 2018 LARAVEL<a href="#"></a>
    </div>
    <div class="footer-block author">
        <ul>
            <li> LOREM
                <a href="#">LOREM</a>
            </li>
            <li>
                <a href="#">bluebox</a>
            </li>
        </ul>
    </div>
</footer>